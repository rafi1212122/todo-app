//
//  ThemeSetting.swift
//  todolist
//
//  Created by Rafi Aburachman on 24/02/21.
//

import SwiftUI

class ThemeSetting: ObservableObject {
    @Published var themeSetting: Int = UserDefaults.standard.integer(forKey: "Theme"){
        didSet{
            UserDefaults.standard.set(self.themeSetting, forKey: "Theme")
        }
    }
    private init() {}
    public static let shared = ThemeSetting()
}
