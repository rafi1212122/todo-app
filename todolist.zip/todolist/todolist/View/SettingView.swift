//
//  SettingView.swift
//  todolist
//
//  Created by Rafi Aburachman on 22/02/21.
//

import SwiftUI

struct SettingView: View {
    @Environment (\.presentationMode) var presentationMode
    @EnvironmentObject var iconSetting : IconNames
    
    let themes:[Theme] = themeData
    @ObservedObject var theme = ThemeSetting.shared
    @State private var isThemeChanged:Bool = false
    
    var body: some View {
        NavigationView{
            VStack(alignment: .center, spacing : 0){
                Form{
                    Section(header: Text("Choose Icon")){
                        Picker(selection: $iconSetting.currentIndex,label:Text("App Icons")){
                            ForEach(0..<iconSetting.iconNames.count){index in
                                HStack{
                                    Image(uiImage: UIImage(named: self.iconSetting.iconNames[index] ?? "Blue") ?? UIImage())
                                        .resizable()
                                        .renderingMode(.original)
                                        .scaledToFit()
                                        .frame(width: 44, height: 44)
                                        .cornerRadius(8)
                                    Spacer()
                                        .frame(width:8)
                                    Text(self.iconSetting.iconNames[index] ?? "Blue")
                                        .frame(alignment:.leading)
                                }
                                .padding(3)
                            }
                        }
                        .onReceive([self.iconSetting.currentIndex].publisher.first()){
                            (value) in
                            let index = self.iconSetting.iconNames.firstIndex(of: UIApplication.shared.alternateIconName)
                            if index != value{
                                UIApplication.shared.setAlternateIconName(self.iconSetting.iconNames[value]){error in
                                    if let error = error{
                                        print(error.localizedDescription)
                                    }else{
                                        print("Berhasil mengubah icon")
                                    }
                                }
                            }
                        }
                    }
                    Section(header:
                                HStack{
                                    Text("Choose App Theme")
                                    Image(systemName: "circle.fill")
                                        .resizable()
                                        .frame(width:10,height:10)
                                        .foregroundColor(themes[self.theme.themeSetting].themeColor)
                                }
                    ){
                        List{
                            ForEach(themes,id: \.id){item in
                                Button(action:{
                                    self.theme.themeSetting = item.id
                                    UserDefaults.standard.set(self.theme.themeSetting, forKey:"Theme")
                                    self.isThemeChanged.toggle()
                                }){
                                    HStack{
                                        Image(systemName:"circle.fill")
                                            .foregroundColor(item.themeColor)
                                        Text(item.themeName)
                                    }
                                }
                                .accentColor(Color.primary)
                            }
                        }
                    }
                    .padding(.vertical,3)
                    .alert(isPresented:$isThemeChanged){
                        Alert(
                            title: Text("Success"),
                            message: Text("App Theme Changed To \(themes[self.theme.themeSetting].themeName)"),
                            dismissButton: .default(Text("OK"))
                        )
                    }
                    
                    Section(header: Text("Follow us on Social Media")){
                        FromRowLinkView(icon: "play", color: Color.pink, text: "Youtube", link: "https://www.youtube.com/")
                        FromRowLinkView(icon: "envelope", color: Color.blue, text: "Email", link: "https://mail.google.com/")
                        FromRowLinkView(icon: "link", color: Color.green, text: "Official Site", link: "https://www.google.com/")
                    }
                    .padding(.vertical, 3)
                    
                    Section(header: Text("")){
                        FromRowStaticView(icon: "gear", firstText: "General", secondText: "Todo")
                        FromRowStaticView(icon: "gear", firstText: "General", secondText: "Todo")
                        FromRowStaticView(icon: "gear", firstText: "General", secondText: "Todo")
                        FromRowStaticView(icon: "gear", firstText: "General", secondText: "Todo")
                        FromRowStaticView(icon: "gear", firstText: "General", secondText: "Todo")
                    }
                }
                .listStyle(GroupedListStyle())
                .environment(\.horizontalSizeClass, .regular)
                Text("Copyright 2021")
                    .multilineTextAlignment(.center)
                    .font(.footnote)
                    .padding(.top, 6)
                    .padding(.bottom, 8)
                    .foregroundColor(Color.secondary)
            }
            .navigationBarItems(trailing: Button(action:{
                self.presentationMode.wrappedValue.dismiss()
            }){
                Image(systemName: "xmark")
            })
            .navigationBarTitle("Setting", displayMode: .inline)
            .background(Color("ColorBase"))
        }
        .accentColor(themes[self.theme.themeSetting].themeColor)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct SettingView_Previews: PreviewProvider {
    static var previews: some View {
        SettingView().environmentObject(IconNames())
    }
}
